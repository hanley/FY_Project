# IOS-XE Basics – Quick Reference Guide

## 1. Overview
Cisco IOS-XE is a modular, Linux-based network operating system that powers Catalyst routers and switches.  
It supports programmability, API access, traditional CLI, automation, and advanced services such as NetFlow, model-driven telemetry, and high availability.

---

## 2. Common Operational Commands

### Interface Status
```
show ip interface brief
show interfaces status
show interfaces <interface>
```

### System Information
```
show version
show environment all
show platform software status control-processor brief
```

### Routing
```
show ip route
show ip ospf neighbor
show ip bgp summary
```

### VLAN & Switching
```
show vlan brief
show interfaces trunk
show spanning-tree summary
```

### Device Security
```
show running-config | include username
show aaa authentication
show login on-failure
```

---

## 3. Basic Configuration Modes

### Enter Global Configuration Mode
```
configure terminal
```

### Interface Mode
```
interface GigabitEthernet0/0/1
 description Uplink Interface
 ip address 192.168.1.1 255.255.255.0
 no shutdown
```

### Save Configuration
```
copy running-config startup-config
```

---

## 4. SSH and Management Access

### Enable SSH
```
ip domain-name example.com
crypto key generate rsa modulus 2048
ip ssh version 2
```

### Create Local Admin User
```
username admin privilege 15 secret StrongPasswordHere
```

### VTY Lines
```
line vty 0 4
 transport input ssh
 login local
 exec-timeout 10
```

---

## 5. Logging & Monitoring

### Syslog
```
logging host 10.1.1.50
logging trap warnings
```

### NetFlow
```
flow exporter EXPORTER-1
 destination 10.1.1.60
 source GigabitEthernet0/0/1
 transport udp 2055

flow monitor MONITOR-1
 exporter EXPORTER-1
 record netflow-original

interface GigabitEthernet0/0/1
 ip flow monitor MONITOR-1 input
```

---

## 6. Useful Troubleshooting Commands

### Ping / Traceroute
```
ping <ip>
traceroute <ip>
```

### Interface Errors
```
show interfaces counters errors
```

### CPU / Memory
```
show processes cpu sorted
show processes memory platform sorted
```

---

## 7. Backups & Restorations

### Backup Running Config to TFTP
```
copy running-config tftp:
```

### Restore
```
copy tftp: running-config
```

---

## 8. IOS-XE Best Practices
- Use role-based access control (AAA).  
- Enable SSH only (disable telnet).  
- Use **description** on every interface.  
- Enable NetFlow for visibility.  
- Regularly export backups.  
- Avoid using `write erase` unless absolutely required.  
- Test configurations on lab routers before production.  

---

_End of iosxe_basics.md_
