# OSPF Configuration Guide for IOS-XE

## 1. Overview
Open Shortest Path First (OSPF) is a link-state routing protocol used in enterprise networks.  
Cisco IOS-XE supports OSPFv2 (IPv4) and OSPFv3 (IPv6).

OSPF uses:
- Areas to segment the network
- LSAs to advertise network state
- DR/BDR selection on broadcast networks
- Cost to determine best paths

---

## 2. Basic OSPFv2 Configuration (IPv4)

### Step 1 — Enable OSPF
```
router ospf 1
 router-id 1.1.1.1
```

### Step 2 — Advertise Networks
```
router ospf 1
 network 192.168.1.0 0.0.0.255 area 0
 network 10.10.10.0 0.0.0.255 area 0
```

### Step 3 — Passive Interface
```
router ospf 1
 passive-interface default
 no passive-interface GigabitEthernet0/0/1
```

---

## 3. Interface-based OSPF (recommended)
```
interface GigabitEthernet0/0/1
 ip ospf 1 area 0
 ip ospf network point-to-point
```

---

## 4. DR / BDR Behavior

OSPF elects a Designated Router (DR) and Backup Designated Router (BDR) on broadcast networks.

```
interface GigabitEthernet0/0/1
 ip ospf priority 200
```

Priority:
- 0 = never be DR  
- Higher = more likely to be DR  

---

## 5. OSPF Authentication

### MD5 authentication
```
interface GigabitEthernet0/0/1
 ip ospf message-digest-key 1 md5 StrongKey
 ip ospf authentication message-digest
```

---

## 6. OSPFv3 (IPv6)

### Enable OSPFv3
```
ipv6 router ospf 10
 router-id 2.2.2.2
```

### Interface activation
```
interface GigabitEthernet0/0/1
 ipv6 ospf 10 area 0
```

---

## 7. Verification Commands

### Neighbor adjacencies
```
show ip ospf neighbor
```

### OSPF database
```
show ip ospf database
```

### Routes
```
show ip route ospf
```

---

## 8. Troubleshooting Checklist
- Subnet masks must match on both ends  
- Area IDs must match  
- MTU mismatch causes stuck-in-EXSTART  
- Authentication mismatches prevent adjacency  
- Router-ID must be unique  

---

_End of ospf_config_guide.md_
