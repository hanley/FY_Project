# VLAN & Inter-VLAN Configuration Guide – Cisco IOS-XE

## 1. What is VLAN?
A Virtual LAN (VLAN) separates a physical network into multiple logical networks.  
VLANs improve segmentation, performance, and security.

Example VLANs:
- VLAN 10 – Users
- VLAN 20 – Servers
- VLAN 30 – Voice

---

## 2. Create VLANs

```
configure terminal
vlan 10
 name USERS
vlan 20
 name SERVERS
vlan 30
 name VOICE
```

---

## 3. Assign VLAN to Access Ports

```
interface GigabitEthernet0/0/1
 switchport mode access
 switchport access vlan 10
 description User PC

interface GigabitEthernet0/0/2
 switchport mode access
 switchport access vlan 20
 description Server Port
```

---

## 4. Configure Trunk Ports

```
interface GigabitEthernet0/0/24
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30
 description Uplink to Router
```

---

## 5. Inter-VLAN Routing Methods

### Method 1 — Router-on-a-Stick
```
interface GigabitEthernet0/0/0
 no shutdown

interface GigabitEthernet0/0/0.10
 encapsulation dot1Q 10
 ip address 192.168.10.1 255.255.255.0

interface GigabitEthernet0/0/0.20
 encapsulation dot1Q 20
 ip address 192.168.20.1 255.255.255.0
```

### Method 2 — Per-Interface VLAN (using L3 switch)
```
interface Vlan10
 ip address 192.168.10.1 255.255.255.0

interface Vlan20
 ip address 192.168.20.1 255.255.255.0

ip routing
```

### Method 3 — SVIs (Switched Virtual Interfaces)
This is the typical Catalyst L3 switch method.

---

## 6. Verification Commands

```
show vlan brief
show interfaces trunk
show ip interface brief
show ip route
```

---

## 7. Troubleshooting Tips
- Access ports must NEVER be trunk mode  
- Trunk must allow the VLAN  
- Router-on-a-stick requires subinterfaces  
- SVI must be **up/up** which means:  
  - VLAN exists  
  - At least 1 access/trunk port is up  
- Ensure default gateways for each VLAN point to the SVI or subinterface IP  

---

_End of vlan_config_guide.md_
